#!/usr/bin/env python
# coding: utf-8

# In[10]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
df=pd.read_csv('IPL_Matches_2022.csv')


# In[3]:


total_matches = df.shape[0]
print("Total matches played:", total_matches)


# In[5]:


teams = df["Team1"].unique()
print("Teams participated:", teams)


# In[7]:


most_wins = df["WinningTeam"].value_counts().idxmax()
print("Team with the most wins:", most_wins)


# In[33]:


team_name = "Royal Challengers Bangalore"  
team_wins = df[df["WinningTeam"] == team_name].shape[0]
print(team_name, "won", team_wins, "matches.")


# In[16]:


winning_team = df["WinningTeam"].value_counts().idxmax()
print("Winner of IPL 2022:", winning_team)


# In[17]:


team_wins = df["WinningTeam"].value_counts()
print("Number of matches won by each team in IPL 2022:\n", team_wins)


# In[22]:


most_common_city = df["City"].value_counts().idxmax()
matches_in_city = df["City"].value_counts().max()
print("City that hosted the maximum number of matches in IPL 2022:", most_common_city)
print("Number of matches hosted in that city:", matches_in_city)


# In[59]:


most_umpire1 = df["Umpire1"].value_counts().idxmax()
print("umpiring done in most matches by 1st umpire:", most_umpire1)
most_umpire_count = df["Umpire1"].value_counts().max()
print("No.of Times umpiring done in matches by 1st umpire:", most_umpire_count)


# In[62]:


most_umpire2 = df["Umpire2"].value_counts().idxmax()
print("umpiring done in most matches by 2st umpire:", most_umpire2)
most_umpire_count = df["Umpire2"].value_counts().max()
print("No.of Times umpiring done in matches by 2st umpire:", most_umpire_count)


# In[58]:


player_name = "Kuldeep Yadav"  
player_motm_wins = df[df["Player_of_Match"] == player_name].shape[0]
print("Number of matches", player_name, "won the 'Man of the Match' award:", player_motm_wins)


# In[46]:


team_matches = pd.concat([df['Team1'], df['Team2']]).value_counts()
plt.figure(figsize=(10, 6))
sns.barplot(x=team_matches.index, y=team_matches.values)
plt.title('Number of Matches Played by Each Team')
plt.xlabel('Teams')
plt.ylabel('Number of Matches')
plt.xticks(rotation=45)
plt.show()


# In[14]:


plt.figure(figsize=(10, 6))
sns.countplot(x='Venue', hue='TossDecision', data=df)
plt.title('Toss Decisions at Different Venues')
plt.xlabel('Venue')
plt.ylabel('Count')
plt.xticks(rotation=45)
plt.legend(title='Toss Decision')
plt.show()


# In[20]:


city_counts = df['City'].value_counts()
num_cities = len(city_counts)
plt.figure(figsize=(10, 6))
colors = sns.color_palette('hsv', num_cities)  
plt.pie(city_counts, labels=city_counts.index, colors=colors, autopct='%1.1f%%', startangle=90)
plt.title('Number of Matches Hosted by City')
plt.axis('equal')  
plt.legend(title='City', loc='best')
plt.show()


# In[61]:


pom_counts = df['Player_of_Match'].value_counts()
players = pom_counts.index
awards = pom_counts.values
plt.figure(figsize=(21, 6)) 
plt.scatter(players, awards)
plt.xlabel('Players')
plt.ylabel('Number of "Player of the Match" Awards')
plt.title('Number of "Player of the Match" Awards for Each Player in IPL 2022')
plt.xticks(rotation=45)  
plt.tight_layout()  
plt.show()


# In[66]:


grouped_data = df.groupby('WinningTeam')['WonBy'].value_counts().unstack()
plt.figure(figsize=(10, 6))  
grouped_data.plot(kind='bar', stacked=True)
plt.xlabel('WinningTeam')
plt.ylabel('Count')
plt.title('Comparison of Toss Winner and Winning Team in IPL 2022')
plt.xticks(rotation=45)  
plt.tight_layout() 
plt.legend(title='Winning Team') 
plt.show()


# In[12]:


import pandas as pd
from sklearn.cluster import KMeans
data = pd.read_csv('IPL_Matches_2022.csv')
X = data[['Season', 'Margin']]
k = 3  
model = KMeans(n_clusters=k)
model.fit(X)
labels = model.labels_
data['Cluster'] = labels
print('Cluster Centers:')
print(model.cluster_centers_)


# In[15]:


import pandas as pd
from sklearn.linear_model import LinearRegression
data = pd.read_csv('IPL_Matches_2022.csv')
X = data[['Margin']]
y = data['ID']
model = LinearRegression()
model.fit(X, y)
predictions = model.predict(X)
print('Intercept:', model.intercept_)
print('Coefficient:', model.coef_)

